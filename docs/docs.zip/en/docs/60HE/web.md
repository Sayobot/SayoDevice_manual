
> ## Software  

 ### No download required. Open website [https://app.sayodevice.com](https://app.sayodevice.com) <!-- {docsify-ignore} -->  
Recommended: [Chrome](https://www.google.cn/chrome/index.html) or **Edge**.  

!> If the page fails to load (over 1 minute), press Ctrl+F5 to refresh.  