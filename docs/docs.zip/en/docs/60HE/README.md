# Welcome to SayoDevice  

### ☜ Help directory on the left <!-- {docsify-ignore} -->  

## Key Layouts  

> K64H3 K64H3MZ  
![alt text](K64_KEYMAP.png)  

> K66H3MZ  
![alt text](K66_KEYMAP.png)  

> K61H3MZ  
![alt text](K61_KEYMAP.png)  
