# Software Version Selection

Please choose one of the following versions according to your needs:

## [Web Version (Recommended)](../std/web_hid/README.md)
Use our web-based configuration tool directly in your browser without installation.

## [Offline Version V3](../std/client/README.md)
Download and install our latest offline configuration software.

## [Offline Version V2 (Legacy)](../std/web/README.md)
This version is no longer updated and not recommended for new users.