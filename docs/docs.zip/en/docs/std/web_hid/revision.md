# Revision History

> 2024.06.19  
- Initial release

> 2025.01.24
- Added 60HE PCB support

> 2025.04.15
- Feature updates
- Magnetic axis parameters added
- Script documentation updated