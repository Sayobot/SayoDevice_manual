# Password

> ## Set the input content
>
> 1. In the **Password** tab, select an entry to enter the content
> </br> 2. In the "Key" tab, change the key mode to "One-key password" or "One-key web page", and select the entry number you just entered
> </br>

---