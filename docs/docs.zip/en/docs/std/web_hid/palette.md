# Color Tables

Manage multiple palettes (used with lighting options)  
Click color blocks to edit. Use eyedropper for screen picking  

![Palette](./img/palette.jpg)