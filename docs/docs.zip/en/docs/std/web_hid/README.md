# Welcome to SayoDevice

### ☜ Navigation on the left <!-- {docsify-ignore} -->

![Main Interface](/img/main.png)