# String

!> Note! ! ! This feature is only available on Windows.
Only some devices support this feature

> ## Set input content
>
> The setting method is similar to one-key password, but there are two encoding methods
> </br> 1. In the **String** tab, select an entry to enter content
> </br> 2. In the "Key" tab, change the key mode to "One-key poem", and select the password number you just entered
> </br>

---

> ## Function principle
>
> The principle is to press Alt+Number keys on the small numeric keyboard to directly enter the character code.
> </br>
> There may be shortcut key conflicts.

---

> ## Character encoding
>
> Supports two encoding methods. Unicode and GBK
> </br>
> If the output is garbled, try switching to another encoding method and resetting the input content