# Select your device type

## [Key Configurations](./std/web_hid/README.md)  

## [Wireless Options](./std/web_hid/rf_opt.md)  

## [Single Knob](./knob/README.md)  

## [LCD Built-in menu](./std/built_in_menu/README.md)  

## [60HE PCB](./60HE/README.md)  



