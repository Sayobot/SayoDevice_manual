# 选择你的设备类型

正确选择才能看到想要的内容哦

## [键盘设置](./std/web_hid/README.md)  

## [无线设置](./std/web_hid/rf_opt.md)  

## [音量控制器（旋钮）设置](./knob/README.md)  

## [小屏内置菜单](./std/built_in_menu/README.md)  

## [磁轴（60%）PCB](./60HE/README.md)  