<!-- docs/_sidebar.md -->

* [返回首页](/README.md)
* [界面说明](./README.md)
* [按键绑定](./key.md)
* [灯光](./led.md)
* [色表](./palette.md)
* [屏幕](./screen.md)
* [磁轴](./HE_CFG.md)
* [磁轴高级功能](./HE_ADV.md)
* [脚本](./script.md)
* [脚本名称](./script_name.md)
<!-- [脚本例程](codebook.md) -->  
<!-- * [脚本录制](script_record.md) -->  
* [备份](./backup.md)
* [设备选项](./device_option.md)
* [无线选项](./rf_opt.md)
* [固件升级](./firmware_update.md)
* [修订](./revision.md)
