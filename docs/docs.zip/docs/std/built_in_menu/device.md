# 设备设置

![图呢？你刷新一下试试？](/img/menu_device.png)  

> ## 回报速率  
修改设备的回报率

![图呢？你刷新一下试试？](/img/menu_pollingrate.png)

---

> ## 关于设备  
这儿没啥可操作的

![图呢？你刷新一下试试？](/img/menu_about.png)

**HW** 硬件版本（可能不准）  
**FW** 固件版本  

---

> ## 按键计数  
显示从出厂或上一次重置按键计数到现在各个按键你按了多少次

![图呢？你刷新一下试试？](/img/menu_counter_reset.png)

**Reset key count** 重置按键计数

---

> ## 恢复出厂  
**不会重置按键计数**

![图呢？你刷新一下试试？](/img/menu_reset_1.png)

**恢复出厂** 相当于确认恢复出厂  
**jump to bootloader** 进入固件更新模式  
**Reset image data** 清除自定义图片
