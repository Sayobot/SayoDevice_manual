# 软件版本选择

以下版本程序都可以用，根据需要选择其一即可

## [网页版 (推荐)](../std/web_hid/README.md)

## [离线版 V3](../std/client/README.md)

## [离线版 V2(不推荐，不再更新)](../std/web/README.md)
