> ## 软件地址

 ###   无需下载，使用浏览器打开 [https://app.sayodevice.com](https://app.sayodevice.com) 即可设置功能  <!-- {docsify-ignore} -->
推荐使用 [Chrome浏览器](https://www.google.cn/chrome/index.html) 或 **Edge浏览器**  
[QQ浏览器](https://browser.qq.com/)、[搜狗高速浏览器](https://ie.sogou.com/)、[360极速浏览器](http://chrome.360.cn/) 亦可，但需要更新到最新版

!> 如果长时间未进入（超过1分钟）请按Ctrl+F5刷新
