# 欢迎使用SayoDevice

### ☜左边有帮助目录 <!-- {docsify-ignore} -->

## 键位布局

> K64H3 K64H3MZ
![alt text](K64_KEYMAP.png)

> K66H3MZ
![alt text](K66_KEYMAP.png)

> K61H3MZ 
![alt text](K61_KEYMAP.png)

---
