# 欢迎使用SayoDevice <!-- {docsify-ignore-all} -->

> # Start 

### ☞[简体中文 :cn:](/docs/device_select.md)  
### ☞[English :us:](/en/docs/device_select.md)  
