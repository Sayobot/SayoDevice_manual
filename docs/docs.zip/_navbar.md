* **[主页](/README.md)**  
* **网页版**  
  * [新版（推荐）](https://app.sayodevice.com)  
  * [旧版（不推荐）](https://old.sayodevice.com)  
* **桌面版**  
  * [键盘设定程序 新版 (Windows)](https://app.sayodevice.com/windows_x64.zip)  
  * [键盘设定程序 新版(Linux)](https://app.sayodevice.com/linux_x64.tar.gz)  
  * [屏幕流式传输工具 (Windows)](https://app.sayodevice.com/firmware/update/5/tools/SayoDeviceStreamingAssistant.zip)  
  * [键盘设定程序 旧版 V2 (Windows/Linux/MacOS)](https://dl.sayobot.cn/setting_v2.zip)  
  * [键盘设定程序 旧版 V3 (Windows)](https://dl.sayobot.cn/setting_v3.zip)  
  
* **文档**  
  * [脚本文档](https://manual.sayodevice.com/docs/std/web_hid/script.md)  
